This ZIP file contains simple C programs you can reverse to train yourself.

For each program, a password is required! When you have found it, fell free to send it to me by message ;)

/!\ Some of these programs were compiled in 64 bits and others in 32 bits /!\

Good luck !


